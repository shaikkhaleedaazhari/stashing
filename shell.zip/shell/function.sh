#!/bin/sh
#Author: khaleeda
#purpose: learning function
#usage: ./function.sh
function hello
{
        echo "hello world"
}
hello

