#!/bin/bash
#Author: khaleeda
#purpose: Compare two numbers
#usage: ./finddir.sh
echo "This is the dirctory with the size"
read -r directory
du -h $directory







#pass the directory and we have to find the size of the directory
