#!/bin/sh
echo "this is for shell script" 
