#!/bin/sh
#Author: khaleeda
#purpose: linux in shell
#usage: ./linux in shell.sh

command="ls -ltr /etc"
echo "$command"
eval $command