#!/bin/sh
#Author: khaleeda
#purpose: linux in shell
#usage: ./linux in shell.sh


#to take a variable and execute it
echo "i am $USERNAME. $USERNAME is a tigeress"
echo "my current working directory is `pwd`"
echo "`who`"
echo "`date`"
ls