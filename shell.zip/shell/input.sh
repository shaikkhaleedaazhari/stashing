#!/bin/sh
echo "this is for shell script" 
#Author: khaleeda
#purpose: creating a variable
#usage: ./variable.sh {var1} {var2}
echo "this is the first value i got : $1"
echo "this is the first value i got : $2"