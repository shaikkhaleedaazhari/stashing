#!/bin/sh
#Author: khaleeda
#purpose: learning function
#usage: ./fcreatingfile.sh

touch test.txt
