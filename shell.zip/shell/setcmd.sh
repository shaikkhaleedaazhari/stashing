#!/bin/sh
#Author: khaleeda
#purpose: learning function
#usage: ./setcmd.sh
set -x    #IMPORTANT
set  `date`
echo "today is $1"
echo "today month is $2"
echo "day is $3"
echo "year is $4"
echo "Am/pm is $6"


