#!/bin/sh
echo "this is for shell script" 

#Author: khaleeda
#purpose: creating a variable
#usage: ./variable.sh
var1=10
var2="Hello"
echo "Today is $var1 day and $var2 me today"
echo "is it time to have lunch after 'date'?"

