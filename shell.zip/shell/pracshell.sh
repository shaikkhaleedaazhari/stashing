#!/bin/bash
#Author: khaleeda
#purpose: Print user input
#usage: ./pracshell.sh

# echo "Write your string:"
# read -r str
# echo "You entered: $str"


# echo "write your number"
# num1=$1
# num2=$2

if [ $num1 -gt $num2 ]; then
    echo "great"
else 
    echo "less"
fi


#pass the directory and we have to find the sxe of the directory